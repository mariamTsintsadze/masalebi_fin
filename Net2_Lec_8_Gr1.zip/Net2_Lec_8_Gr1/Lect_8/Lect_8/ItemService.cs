﻿//using Database;
using Domain.DomainModels;
//using Domain.Dtos;
//using Mapster;
//using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace Services
{
    public class ItemService : IItemService
    {
        private List<Item> _items = new();
        private IMemoryCache _cache;

        public ItemService(IMemoryCache cache)
        {
            _cache = cache;
        }

        public void Add(Item item)
        {
            List<Item> items;

            if (!_cache.TryGetValue("items", out items))
            {
                items = new List<Item>();
            }

            items.Add(item);

            // განაახლე ქეში ახალი სიის ვერსიით
            _cache.Set("items", items);
        }

        public List<Item> GetAllItemsFromCache()
        {
            _cache.TryGetValue("items", out List<Item> _items);

            if (_items != null)
            {
                return _items;
            }
            else
            {
                return new List<Item>();
            }
        }

        public List<Item> GetItemsByPage(int pageIndex, int pageSize)
        {
            _cache.TryGetValue("items", out List<Item> items);

            return items.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();

            
        }

        public List<Item> FilterItems(int minYear, string type)
        {
            _cache.TryGetValue("items", out List<Item> items);

            return items
               .Where(x => x.CreateYear > minYear &&
                            x.Type == type)
                //.OrderBy(x => x.CreateYear)
                .ToList();

             
        }
    }
}
