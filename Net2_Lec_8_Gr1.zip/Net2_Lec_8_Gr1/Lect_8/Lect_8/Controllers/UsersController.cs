﻿using Domain.Dtos;
using Lect_8.Models;
using Mapster;
using Microsoft.AspNetCore.Mvc;
using Services;

namespace Lect_8.Controllers
{
    [Route("api/users")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private static List<User> _users = new List<User>();
        private static int _userId = 1;



        //public IItemService _itemService;

        //public ItemsController(IItemService itemService)
        //{
        //    _itemService = itemService;
        //}

        //[HttpGet("GetAllItemsInfo")]
        //public List<Item> GetAllItemssFromCache()
        //{
        //    var people = _itemService.GetAllItemsFromCache();

        //    return people;
        //}

        //[HttpPost]
        //public void Add(Item item)
        //{
        //    _itemService.Add(item);
        //}

        //[HttpGet("GetItemsByPage")]
        //public List<Item> GetItemsByPage(int pageIndex, int pageSize)
        //{
        //    return _itemService.GetItemsByPage(pageIndex, pageSize);
        //}

        //[HttpGet("GetItemsYearAndType")]
        //public List<Item> FilterItems(int minYear, string type)
        //{
        //    return _itemService.FilterItems(minYear, type);
        //}

        //---mapster---
        //public List<PersonDto> GetPersonInfoByMapping()
        //{
        //    var people = _personDBContext.People.ToList();

        //    var peopleDto = people.Adapt<List<PersonDto>>();

        //    return peopleDto;

        //}


        [HttpPost("register-annotated")]
        public IActionResult CreateUser([FromBody] CreateUserRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Email))
            {
                throw new Exception("Email cannot be empty.");
            }

            var user = request.Adapt<User>();
            user.Id = _userId++;
            _users.Add(user);

            return Ok(user);
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded.");

            var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "UploadedFiles");
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            var filePath = Path.Combine(folderPath, file.FileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            return Ok(new { message = "File uploaded successfully.", fileName = file.FileName });
        }
    }
}
