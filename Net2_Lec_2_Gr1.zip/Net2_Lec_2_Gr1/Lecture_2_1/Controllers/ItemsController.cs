﻿using Domain.DomainModels;
//using Domain.Dtos;
using Microsoft.AspNetCore.Mvc;
using Services;

namespace Lecture_2_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemsController : ControllerBase
    {
        public IItemService _itemService;

        public ItemsController(IItemService itemService)
        {
            _itemService = itemService;
        }

        [HttpGet("GetAllItemsInfo")]
        public List<Item> GetAllItemssFromCache()
        {
            var people = _itemService.GetAllItemsFromCache();

            return people;
        }

        [HttpPost]
        public void Add(Item item)
        {
             _itemService.Add(item);
        }

        [HttpGet("GetItemsByPage")]
        public List<Item> GetItemsByPage(int pageIndex, int pageSize)
        {
            return _itemService.GetItemsByPage(pageIndex, pageSize);
        }

        [HttpGet("GetItemsYearAndType")]
        public List<Item> FilterItems(int minYear, string type)
        {
            return _itemService.FilterItems(minYear, type);
        }
    }
}
