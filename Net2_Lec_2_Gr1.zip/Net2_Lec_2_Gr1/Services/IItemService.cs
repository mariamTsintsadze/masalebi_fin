﻿using Domain.DomainModels;

namespace Services
{
    public interface IItemService
    {
        public void Add(Item item);
        public List<Item> GetAllItemsFromCache();
        public List<Item> GetItemsByPage(int pageIndex, int pageSize);
        public List<Item> FilterItems(int minYear, string type);
    }
}
