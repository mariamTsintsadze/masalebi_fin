﻿namespace Domain.Dtos
{
    public class PersonDto
    {
        public string FirstName { get; set; }
        public int Age { get; set; }
    }
}
