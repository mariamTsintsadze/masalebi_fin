﻿namespace Domain.DomainModels
{
    public class Item
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public int CreateYear { get; set; }
        public bool IsAvailable { get; set; }
    }
}
